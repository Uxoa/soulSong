// src/components/profiles/ProfileCard.tsx
import React from "react";
import { useNavigate } from "react-router-dom";

type ProfileCardProps = {
    id: string;
    name: string;
    imageUrl: string;
    favoriteSong?: string;
};

const ProfileCard: React.FC<ProfileCardProps> = ({ id, name, imageUrl, favoriteSong }) => {
    const navigate = useNavigate();

    const handleViewProfile = () => {
        navigate(`/profiles/${id}`);
    };

    return (
        <div className="p-4 bg-white rounded-lg shadow-md">
            <img
                src={imageUrl}
                alt={`${name}'s profile`}
                className="w-20 h-20 rounded-full mx-auto"
            />
            <h2 className="text-lg font-bold text-center mt-2">{name}</h2>
            <p className="text-sm text-gray-500 text-center">
                Favorite Song: {favoriteSong || "None"}
            </p>
            <button
                onClick={handleViewProfile}
                className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full"
            >
                View Profile
            </button>
        </div>
    );
};

export default ProfileCard;
