// src/components/profiles/ProfileManager.tsx
import React from "react";
import useProfiles from "../../hooks/useProfiles";
import ProfileCard from "./ProfileCard";

const ProfileManager: React.FC = () => {
    const { profiles, loading, error } = useProfiles();

    if (loading) return <p>Loading profiles...</p>;
    if (error) return <p>Error loading profiles: {error}</p>;

    return (
        <div className="container mx-auto p-6">
            <h1 className="text-2xl font-bold mb-6">User Profiles</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {profiles.map((profile) => (
                    <ProfileCard
                        key={profile.id}
                        id={profile.id}
                        name={profile.name}
                        imageUrl={profile.imageUrl}
                        favoriteSong={profile.favoriteSong?.name}
                    />
                ))}
            </div>
        </div>
    );
};

export default ProfileManager;
